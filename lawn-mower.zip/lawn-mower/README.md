# Lawn Mower

An automatic lawn mower designed to mow rectangular surfaces.

## Installation

Use the package manager npm to install Lawn Mower.

```bash
npm install
```

## Usage

# src folder

Contains the main file of the program and the modules it uses. 
main.js - the main file
lawn.js - the class representing the lawn
mower.js - the class representing the mower
input-validation-service.js - a module validating the correctness of the input


# tests folder

Tests folder contains 3 folders:
- input files that look according to the instructions.
- output files there the programs writes its output.
- expected output files that contain the output expected from the input file.

It also contains the first test, described in the exercise, which takes the given input file, runs it, and compared the output of the program to the expected output file. 

# Run the test

1. cd tests
2. node test-a.js

The test activates the main of the Lawn Mower program with the path of the input file and the path to write the out put file. 

# Vslidate the test

There are two way to check the correctess of the program, you can commant out any one of the two:

1. The first one gets the output as an array of strings and compares the output file with the expected file. 
It alerts when a specific line failed with its details. 

2. The second once uses the output file and compares the output file with the expected file.