const positionOrientationCondition = ["N","E","S","W"];
const instructionCondition = ["R","L","F"];

export function validateLine(line, arraySize) {
    if (positionOrientationCondition.some(el => line.includes(el)) && arraySize===3){ // line of the mowner
        return true;
    }else if (instructionCondition.some(el => line.includes(el)) && arraySize===1){ // line of the instuctions
        return true;
    }else if (arraySize===2) { // line of the lawn
        return true;
    }
    return false;
}