export class Lawn {
  
    #compass = {
      "N" : {
        "L": "W",
        "R" : "E"
      },
      "E": {
        "L": "N",
        "R" : "S"
      },
      "S" : {
        "L": "E",
        "R" : "W"
      },
      "W" : {
        "L": "S",
        "R" : "N"
      }
    };

    constructor(width, height) {
      this._width =width;
      this._height = height;
    }

    toString(){
      return this._width +' '+this._height;
    }

    moveForward(mower){
      switch(mower.orientation) {
        case 'N':
          if (mower.y+1 <= this._height) mower.y = mower.y+1;
          break;
        case 'E':
          if (mower.x+1 <= this._width) mower.x = mower.x+1;
          break; 
        case 'S':
          if (mower.y-1 >= 0) mower.y = mower.y-1;
          break; 
        case 'W':
          if (mower.x-1 >= 0) mower.x = mower.x-1;
          break;
      }
    }

    move(mower, instruction){
      let o = mower.orientation;
      switch(instruction) {
        case 'R': // move 90 deg right
        case 'L': // move 90 deg left
          mower.orientation=this.#compass[o][instruction];
          break;
        case 'F': // move forward
          this.moveForward(mower);
      }
    }
    
  }