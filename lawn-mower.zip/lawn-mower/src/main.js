import * as lineReader from 'line-reader';
import Promise from 'bluebird';
import * as fs from 'fs';

import * as validationService from './input-validation-service.js';
import {Mower} from './mower.js';
import {Lawn} from './lawn.js';

export default async function main(inputFilePath,outputFilePath){
    
    let theLawn, currMower;
    let output = [];
    let eachLine = Promise.promisify(lineReader.eachLine);

    //if output file exists - override it
    try{
        fs.writeFile(outputFilePath, '', function(){});
    }catch (err){
        console.log(`Wasn't able to override ${outputFilePath}.`);
        return output;
    }
    
    await eachLine(inputFilePath, function (line) {
        let lineDataArr = line.split(' ');
        try{
            // validate line
            let valideLine = validationService.validateLine(line, lineDataArr.length);
            if (!valideLine){
                throw new Error(`The following line isn't valid: ${line}.`);
            }else{
                switch (lineDataArr.length) {
                    case 2:
                        // initiate lawn line
                        theLawn = new Lawn(+lineDataArr[0], +lineDataArr[1]);
                        break;
                    case 3:
                        // initiate mower line
                        currMower = new Mower(+lineDataArr[0], +lineDataArr[1], lineDataArr[2]);
                        break;
                    case 1:
                        if(!theLawn ||!currMower)
                            throw new Error(`Incorrect order of line. Can't perform line: ${line}.`);
                            
                        // handle line of instructions & output
                        let instructionsArr = line.split('');
                        for (let i = 0; i < instructionsArr.length; i++) {
                            theLawn.move(currMower, instructionsArr[i]);
                        }
                        console.log(currMower.toString());
                        try{ //report position
                            fs.appendFileSync(outputFilePath, currMower.toString() + '\n');
                        }catch (err){
                            console.log(`Wasn't able to write to ${outputFilePath}.`);
                            return output;
                        }
                        output.push(currMower.toString());
                }
            }
        }catch (err){
            console.log('Error: ', err);
            process.exit(-1);
        }
    });
    return output;
}