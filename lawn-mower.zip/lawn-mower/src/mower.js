export class Mower {
    constructor(x, y, orientation) {
      this._x = x;
      this._y = y;
      this._orientation=orientation;
    }

    get x() {
        return this._x;
    }

    get y() {
        return this._y;
    }

    get orientation() {
        return this._orientation;
    }
    
    set x(value) {
        this._x = value;
    }

    set y(value) {
        this._y = value;
    }

    set orientation(value) {
        this._orientation = value;
    }
    
    toString(){
        return this._x +' '+this._y + ' '+ this._orientation;
    }

  }