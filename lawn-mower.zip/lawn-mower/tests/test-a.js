import * as lawnMower from '../src/main.js';
import * as lineReader from 'line-reader';
import Promise from 'bluebird';
import * as fs from 'fs';

const inputFilePath = '../tests/input-files/input.a.txt';
const outputFilePath = '../tests/output-files/output.a.txt';
const expectedFilePath = './expected-files/expected.output.a.txt';
const recievedFilePath = './output-files/output.a.txt'; // end up using output array instead

function strcmp(a, b) {
    if (a.toString() < b.toString() || a.toString() > b.toString()) return false;
    return true;
}

async function main(){

    let outputLines = await lawnMower.default(inputFilePath, outputFilePath);

    // #1 - compare expected output to output lines array
    let index = 0;
    let eachLine = Promise.promisify(lineReader.eachLine);
    let failed = false;
    await eachLine(expectedFilePath, function (line) { 
        if(line !== outputLines[index]){
            failed=true;
            console.log(`Test A failed in line ${outputLines[index]} expected ${line}.`);
        } 
        index++;
    });
    if(!failed) console.log('Test A passed successfuly.');
    
    // #2 - compare expected output file to actual output file
    // fs.readFile(expectedFilePath, (err1, expectedData) => { 
    //     let expectedOutput=expectedData.toString().replace(/[\n\t\r]/g,"");
    //     if (err1) {
    //       return;
    //     }
      
    //     fs.readFile(recievedFilePath, (err2, recievedData) => {
    //       let recievedOutput=recievedData.toString().replace(/[\n\t\r]/g,"");
    //       if (err2) {
    //         return;
    //       }
      
    //       if(strcmp(expectedOutput,recievedOutput)){
    //         console.log('Test A passed successfuly.');
    //       }else{
    //         console.log('Test A failed.');
    //       }
          
    //     });
    // });

};

main().catch(function(err){
    console.log('Error: ', err);
    process.exit(-1);
});